module.exports=[88783,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_about-us_page_actions_5f40c926.js.map
module.exports=[32096,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_case-studies_page_actions_45bbcb4d.js.map
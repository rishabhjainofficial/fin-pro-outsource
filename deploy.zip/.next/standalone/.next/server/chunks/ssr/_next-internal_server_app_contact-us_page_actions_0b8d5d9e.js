module.exports=[58010,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_contact-us_page_actions_0b8d5d9e.js.map
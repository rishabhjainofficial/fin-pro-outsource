module.exports=[90070,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_cpa-firm_%5Bslug%5D_page_actions_37a9de00.js.map
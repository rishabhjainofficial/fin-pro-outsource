module.exports=[73675,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_how-we-work_page_actions_d7580e06.js.map
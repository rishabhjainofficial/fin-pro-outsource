module.exports=[71073,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_services_%5Bcategory%5D_%5Bslug%5D_page_actions_fb290bc7.js.map
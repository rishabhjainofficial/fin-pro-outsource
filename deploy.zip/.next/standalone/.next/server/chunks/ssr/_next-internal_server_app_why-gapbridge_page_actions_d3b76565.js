module.exports=[458,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_why-gapbridge_page_actions_d3b76565.js.map
module.exports=[26758,a=>{a.v("/_next/static/media/favicon.9950ddee.ico")},38872,a=>{"use strict";let b={src:a.i(26758).default,width:48,height:48};a.s(["default",0,b])}];

//# sourceMappingURL=app_b9b1292a._.js.map